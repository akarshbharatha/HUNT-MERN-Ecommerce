import { useAuth } from "../context/AuthContext";

function Profile() {
  const { user } = useAuth();

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-white rounded-2xl shadow-lg p-8 border">

        <h1 className="text-3xl font-bold mb-8">
          My Profile
        </h1>

        <div className="space-y-6">

          <div>
            <p className="text-sm text-gray-500">Full Name</p>
            <h2 className="text-xl font-semibold">
              {user?.name}
            </h2>
          </div>

          <div>
            <p className="text-sm text-gray-500">Email</p>
            <h2 className="text-xl font-semibold">
              {user?.email}
            </h2>
          </div>

          <div>
            <p className="text-sm text-gray-500">Role</p>
            <h2 className="text-xl font-semibold capitalize">
              {user?.role}
            </h2>
          </div>

        </div>

      </div>
    </div>
  );
}

export default Profile;