import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  FiShoppingBag,
  FiHeart,
  FiSearch,
  FiMenu,
  FiX,
} from "react-icons/fi";

import { useCart } from "../../context/CartContext";
import { useAuth } from "../../context/AuthContext";

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const { cartCount } = useCart();
  const { user, logout } = useAuth();

  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-neutral-200 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">

        {/* Logo */}
        <div className="flex-1 lg:flex-none">
          <Link
            to="/"
            className="text-2xl font-bold tracking-widest text-neutral-900"
          >
            HUNT
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8 text-sm font-medium tracking-wide">
          <Link
            to="/shop"
            className="text-neutral-600 hover:text-neutral-900 transition-colors"
          >
            Shop All
          </Link>

          <Link
            to="/shop"
            className="text-neutral-600 hover:text-neutral-900 transition-colors"
          >
            Oversized Hoodies
          </Link>

          <Link
            to="/shop"
            className="text-neutral-600 hover:text-neutral-900 transition-colors"
          >
            Sweatshirts
          </Link>

          <Link
            to="/"
            className="text-neutral-600 hover:text-neutral-900 transition-colors"
          >
            Our Story
          </Link>
        </nav>

        {/* Right Side */}
        <div className="flex flex-1 items-center justify-end space-x-5">

          <button
            className="text-neutral-600 hover:text-neutral-900"
            aria-label="Search"
          >
            <FiSearch className="h-5 w-5" />
          </button>

          <button
            className="text-neutral-600 hover:text-neutral-900"
            aria-label="Wishlist"
          >
            <FiHeart className="h-5 w-5" />
          </button>

          {/* Cart */}
          <Link
            to="/cart"
            className="relative text-neutral-600 hover:text-neutral-900"
          >
            <FiShoppingBag className="h-5 w-5" />

            <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-black text-[10px] font-bold text-white">
              {cartCount}
            </span>
          </Link>

          {/* Authentication */}
          {user ? (
            <>
              <span className="hidden lg:block text-sm font-semibold text-neutral-700">
                👋 Hi, {user.name.split(" ")[0]}
              </span>

              <button
                onClick={handleLogout}
                className="hidden lg:block rounded-lg border border-neutral-300 px-4 py-2 text-sm font-medium hover:bg-neutral-100 transition"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="hidden lg:block text-sm font-medium text-neutral-700 hover:text-black"
              >
                Login
              </Link>

              <Link
                to="/register"
                className="hidden lg:block rounded-lg bg-black px-4 py-2 text-sm font-medium text-white hover:bg-neutral-800 transition"
              >
                Register
              </Link>
            </>
          )}

          {/* Mobile Menu */}
          <button
            className="md:hidden text-neutral-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <FiX className="h-6 w-6" />
            ) : (
              <FiMenu className="h-6 w-6" />
            )}
          </button>

        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-neutral-200 bg-white px-4 py-4 space-y-4 shadow-lg">

          <Link
            to="/shop"
            onClick={() => setIsMenuOpen(false)}
            className="block"
          >
            Shop All
          </Link>

          <Link
            to="/shop"
            onClick={() => setIsMenuOpen(false)}
            className="block"
          >
            Oversized Hoodies
          </Link>

          <Link
            to="/shop"
            onClick={() => setIsMenuOpen(false)}
            className="block"
          >
            Sweatshirts
          </Link>

          <Link
            to="/"
            onClick={() => setIsMenuOpen(false)}
            className="block"
          >
            Our Story
          </Link>

          <hr />

          {user ? (
            <>
              <p className="font-semibold">
                👋 Hi, {user.name.split(" ")[0]}
              </p>

              <button
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="w-full rounded-lg bg-black py-2 text-white"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                onClick={() => setIsMenuOpen(false)}
                className="block"
              >
                Login
              </Link>

              <Link
                to="/register"
                onClick={() => setIsMenuOpen(false)}
                className="block"
              >
                Register
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}

export default Navbar;